"""Collect aggregate financial decision-evidence counts in a read-only transaction."""
from __future__ import annotations
import json,subprocess
from datetime import UTC,datetime
SQL=r"""
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='90s';
SELECT jsonb_build_object(
 'financial_fact_total',(SELECT count(*) FROM data_center_financial_fact),
 'financial_fact_announced_at_count',(SELECT count(*) FROM data_center_financial_fact WHERE announced_at IS NOT NULL),
 'financial_fact_available_at_count',(SELECT count(*) FROM data_center_financial_fact WHERE available_at IS NOT NULL),
 'financial_fact_decision_evidence_count',(SELECT count(*) FROM data_center_financial_fact WHERE decision_evidence IS NOT NULL AND decision_evidence <> '{}'::jsonb),
 'financial_fact_source_time_witness_count',(SELECT count(*) FROM data_center_financial_fact WHERE decision_evidence ? 'source_time_witness'),
 'source_time_claim_count',(SELECT count(*) FROM data_center_financial_source_time_audit_claim),
 'source_time_bound_claim_count',(SELECT count(*) FROM data_center_financial_source_time_audit_claim WHERE audit_id IS NOT NULL),
 'source_time_artifact_audit_count',(SELECT count(*) FROM data_center_raw_audit WHERE extra ? 'financial_source_time_artifact'),
 'source_time_success_audit_count',(SELECT count(*) FROM data_center_raw_audit WHERE extra ? 'financial_source_time_artifact' AND status='ok'),
 'latest_source_time_audit_at',(SELECT max(fetched_at) FROM data_center_raw_audit WHERE extra ? 'financial_source_time_artifact')
);
ROLLBACK;
"""
def main()->int:
 cmd=['docker','exec','-i','agomtradepro-postgres-1','sh','-lc','exec psql -X -q -A -t -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"']
 p=subprocess.run(cmd,input=SQL,capture_output=True,text=True,timeout=120,check=False)
 if p.returncode!=0:
  print(json.dumps({'schema':'production-financial-decision-evidence-readonly.v1','exit_code':p.returncode,'error':'read-only query failed','mutations_performed':False},sort_keys=True,separators=(',',':'))); return 1
 lines=[x for x in p.stdout.splitlines() if x.strip()]
 if len(lines)!=1: raise ValueError('unexpected rows')
 print(json.dumps({'schema':'production-financial-decision-evidence-readonly.v1','observed_at_utc':datetime.now(UTC).isoformat().replace('+00:00','Z'),'transaction':'REPEATABLE READ READ ONLY; ROLLBACK','facts':json.loads(lines[0]),'mutations_performed':False,'secret_values_emitted':False},sort_keys=True,separators=(',',':'))); return 0
if __name__=='__main__': raise SystemExit(main())
