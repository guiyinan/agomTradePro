"""Collect exact active canonical publication pointers in a read-only transaction."""
from __future__ import annotations
import json, subprocess
from datetime import UTC, datetime
SQL=r"""
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '90s';
SELECT COALESCE(jsonb_agg(to_jsonb(row_data) ORDER BY dataset_key),'[]'::jsonb)
FROM (
 SELECT p.dataset_key,p.publication_key,p.publication_id AS pointer_publication_id,
        p.publication_hash AS pointer_publication_hash,p.activation_id,p.updated_at AS pointer_updated_at,
        c.state,c.member_count,c.coverage_requested_count,c.coverage_eligible_count,
        c.coverage_selected_count,c.coverage_missing_count,c.coverage_conflict_count,
        c.as_of,c.published_at,c.must_not_use_for_decision,c.blocked_reason,
        (c.publication_id IS NOT NULL AND c.publication_hash=p.publication_hash AND c.state='published' AND c.must_not_use_for_decision=false) AS pointer_resolves_eligible
 FROM data_center_canonical_publication_pointer p
 LEFT JOIN data_center_canonical_publication c
   ON c.publication_id=p.publication_id AND c.dataset_key=p.dataset_key AND c.publication_key=p.publication_key
 WHERE p.publication_key='current' AND p.dataset_key IN ('equity.quote.snapshot','equity.price.bar','equity.valuation.fact','equity.financial.fact')
) row_data;
ROLLBACK;
"""
def main()->int:
 cmd=['docker','exec','-i','agomtradepro-postgres-1','sh','-lc','exec psql -X -q -A -t -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"']
 p=subprocess.run(cmd,input=SQL,capture_output=True,text=True,timeout=120,check=False)
 if p.returncode!=0:
  print(json.dumps({'schema':'production-current-publication-pointer-readonly.v1','exit_code':p.returncode,'error':'read-only query failed','mutations_performed':False},sort_keys=True,separators=(',',':'))); return 1
 lines=[line for line in p.stdout.splitlines() if line.strip()]
 if len(lines)!=1: raise ValueError('unexpected rows')
 print(json.dumps({'schema':'production-current-publication-pointer-readonly.v1','observed_at_utc':datetime.now(UTC).isoformat().replace('+00:00','Z'),'transaction':'REPEATABLE READ READ ONLY; ROLLBACK','pointers':json.loads(lines[0]),'mutations_performed':False,'secret_values_emitted':False},sort_keys=True,separators=(',',':')))
 return 0
if __name__=='__main__': raise SystemExit(main())
