"""Stream one local read-only probe to the trusted production VPS."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import paramiko


def main() -> int:
    """Run the selected probe through VPS stdin without persisting credentials."""

    if len(sys.argv) != 2:
        raise SystemExit("usage: stream_vps_readonly.py PROBE_PATH")
    probe = Path(sys.argv[1]).resolve()
    source = probe.read_text(encoding="utf-8")
    client = paramiko.SSHClient()
    client.load_host_keys(str(Path.home() / ".ssh" / "known_hosts"))
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    client.connect(
        os.environ["AGOM_VPS_HOST"],
        port=int(os.environ.get("AGOM_VPS_PORT", "22")),
        username=os.environ["AGOM_VPS_USER"],
        password=os.environ["AGOM_VPS_PASS"],
        timeout=20,
        look_for_keys=False,
        allow_agent=False,
    )
    try:
        stdin, stdout, stderr = client.exec_command("python3 -", timeout=180)
        stdin.write(source)
        stdin.channel.shutdown_write()
        output = stdout.read()
        error = stderr.read()
        status = stdout.channel.recv_exit_status()
    finally:
        client.close()
    sys.stdout.buffer.write(output)
    sys.stderr.buffer.write(error)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
