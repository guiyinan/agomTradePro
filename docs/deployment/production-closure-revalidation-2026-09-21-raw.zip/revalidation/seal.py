"""Seal the 2026-09-21 production closure read-only revalidation."""

from __future__ import annotations

import hashlib
import json
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
DEST = ROOT / "docs" / "deployment"
STEM = "production-closure-revalidation-2026-09-21"


def _read(name: str) -> dict[str, object]:
    value = json.loads(WORK.joinpath(name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"{name} must contain one JSON object")
    return value


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


identity = _read("current-identity.json")
protected = _read("protected-stop-lines.json")
database = _read("database-readonly.json")
repair = _read("data02-repair-preview.json")
publication = _read("data02-publication-preview.json")
gates = (
    json.loads(WORK.joinpath("final-gates.json").read_text(encoding="utf-8"))
    if WORK.joinpath("final-gates.json").exists()
    else None
)

assert identity["mutations_performed"] is False
manifest = identity["manifest"]
assert isinstance(manifest, dict)
assert manifest["source_commit"] == "439468482f457884db17da47d7566a5aac295842"
https = identity["https"]
assert isinstance(https, dict)
assert {path: value["status"] for path, value in https.items()} == {
    "/api/decision-ready/": 503,
    "/api/health/": 200,
    "/api/health/db/": 200,
    "/api/operational-readiness/release-identity/": 403,
    "/api/ready/": 200,
}
assert protected["decision"] == "DENY_STOP_LINES"
assert protected["protected_query_authenticated_status"] == 401
assert protected["protected_query_unauthenticated_status"] == 401
assert database["mutations_performed"] is False
assert database["transaction"] == "REPEATABLE READ READ ONLY; ROLLBACK"
facts = database["facts"]
assert isinstance(facts, dict) and facts["active_a_share_asset_count"] == 5565
profiles = facts["active_profiles"]
assert isinstance(profiles, list) and len(profiles) == 1 and profiles[0]["version"] == 17
runtime = facts["audit_runtime_values"]
assert isinstance(runtime, dict)
assert runtime["audit.system_event.mode"]["value"] == "off"
assert runtime["audit.system_event.outbox_enabled"]["value"] is False
assert "audit.system_event.authority_selector" not in runtime
authority = facts["authority_counts"]
assert isinstance(authority, dict)
assert authority["temporally_current_actor_leaf_heads"] == 0
assert authority["temporally_current_owner_leaf_heads"] == 0
assert authority["temporally_current_joined_actor_owner_pairs"] == 0
publications = facts["core_current_publications"]
assert isinstance(publications, list) and len(publications) == 4
members = {item["dataset_key"]: item["member_count"] for item in publications}
assert members == {
    "equity.financial.fact": 80,
    "equity.price.bar": 5565,
    "equity.quote.snapshot": 5565,
    "equity.valuation.fact": 5565,
}
assert repair["mutations_performed"] is False and repair["execute_flag_supplied"] is False
assert repair["stderr_last_line"] == (
    "CommandError: latest completed China market session is unavailable during live trading"
)
assert publication["mutations_performed"] is False
assert publication["execute_flag_supplied"] is False
assert publication["stderr_last_line"] == "CommandError: financial source announced_at is required"
if gates is not None:
    assert isinstance(gates, list) and all(item["exit_code"] == 0 for item in gates)

archive_members: dict[str, bytes] = {}
for name in (
    "current-identity.json",
    "protected-stop-lines.json",
    "database-readonly.json",
    "data02-repair-preview.json",
    "data02-publication-preview.json",
    "stream_vps_readonly.py",
    "current_identity_probe.py",
    "production_database_probe.py",
    "data02_preview_probe.py",
    "data02_publication_preview_probe.py",
    "seal.py",
    "final_gates.py",
):
    archive_members[f"revalidation/{name}"] = WORK.joinpath(name).read_bytes()
archive_members["revalidation/evid09_protected_https_stop_probe.py"] = ROOT.joinpath(
    "scripts/evid09_protected_https_stop_probe.py"
).read_bytes()
for name in (
    "current-identity.json.stderr",
    "protected-stop-lines.json.stderr",
    "database-readonly.json.stderr",
    "data02-repair-preview.json.stderr",
    "data02-publication-preview.json.stderr",
):
    archive_members[f"revalidation/{name}"] = WORK.joinpath(name).read_bytes()
if gates is not None:
    archive_members["revalidation/final-gates.json"] = WORK.joinpath(
        "final-gates.json"
    ).read_bytes()
    for gate in gates:
        name = str(gate["name"])
        archive_members[f"revalidation/final-{name}.log"] = WORK.joinpath(
            f"final-{name}.log"
        ).read_bytes()

archive = DEST / f"{STEM}-raw.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for name, raw in sorted(archive_members.items()):
        handle.writestr(name, raw)
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert set(handle.namelist()) == set(archive_members)
    for name, raw in archive_members.items():
        assert handle.read(name) == raw

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
production_commit = str(manifest["source_commit"])
commits = subprocess.check_output(
    ["git", "log", "--format=%H %s", f"{production_commit}..{head}"],
    cwd=ROOT,
    text=True,
).splitlines()
report = {
    "schema": "production-closure-revalidation.v1",
    "status": "blocked_production_exits_not_promoted",
    "sealed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
    "repository_head": head,
    "repository_branch": "dev/next-development",
    "production_commit": production_commit,
    "production_release_tag": manifest["release_tag"],
    "production_is_behind_repository_head": production_commit != head,
    "candidate_commits_not_deployed": commits,
    "observations": {
        "public_https": https,
        "protected_monitoring": protected,
        "database": database,
        "data02_repair_preview": repair,
        "data02_publication_preview": publication,
    },
    "derived_findings": [
        "Production remains 439468482 / 20260920184626; repository AUD-05 follow-up fixes are not deployed.",
        "Health, database health and ready are 200 while decision-ready remains fail-closed at 503.",
        "The protected monitoring credential path still returns 401 authenticated and unauthenticated, so no TUI-02 retained sample may be bound.",
        "The frozen active-A-share denominator is 5,565. Quote, completed-session price and valuation current publications each have 5,565 members; the financial current publication has only 80.",
        "The four-Publication dry-run fails closed because financial source announced_at is absent.",
        "The repair dry-run was attempted during live trading and correctly refused because a latest completed session was unavailable; rerun after market close.",
        "Authority ledgers contain historical rows, but no temporally current actor leaf, owner leaf or joined actor-owner pair exists. The active v17 profile remains mode=off, outbox=false and has no authority selector.",
    ],
    "state_transitions": {
        "DATA-02": "awaiting_production -> awaiting_production",
        "EVID-01": "awaiting_production -> awaiting_production",
        "EVID-02": "awaiting_production -> awaiting_production",
        "AUD-03": "awaiting_production -> awaiting_production",
        "TUI-02": "active -> active",
    },
    "gates": gates or [],
    "next_gates": [
        "Rerun the no-execute DATA-02 repair preview after the China market session completes.",
        "Obtain genuine current actor and owner authority sources; do not extend or reuse expired clocks.",
        "Repair financial announced_at and exact source provenance through an authorized source-backed path, then rerun the four-Publication preview.",
        "Deploy the reviewed repository candidate before using the AUD-05 corrective activation path; deployment and profile activation remain separate authorized actions.",
        "Restore protected-query authentication and obtain a real current-candidate sample before TUI-02 rebind.",
    ],
    "production_mutations_performed": False,
    "secrets_or_row_values_emitted": False,
    "raw_archive": {
        "path": archive.relative_to(ROOT).as_posix(),
        "sha256": _sha(archive.read_bytes()),
        "members": {
            name: {"bytes": len(raw), "sha256": _sha(raw)}
            for name, raw in sorted(archive_members.items())
        },
    },
}
raw_report = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
evidence = DEST / f"{STEM}.json"
evidence.write_bytes(raw_report)
evidence.with_suffix(".json.sha256").write_bytes(
    f"{_sha(raw_report)}  {evidence.name}\n".encode("ascii")
)
print(
    json.dumps(
        {
            "evidence": str(evidence),
            "sha256": _sha(raw_report),
            "archive_sha256": report["raw_archive"]["sha256"],
            "archive_members": len(archive_members),
        },
        sort_keys=True,
    )
)
