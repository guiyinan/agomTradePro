"""Persist final governance validation for the production read-only checkpoint."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
PYTHON = str(ROOT / "agomtradepro" / "Scripts" / "python.exe")
CHECKS = (
    ("registry", [PYTHON, "scripts/check_active_plan_registry.py"]),
    ("governance", [PYTHON, "scripts/check_governance_consistency.py"]),
    ("current-data", [PYTHON, "scripts/check_current_data_contracts.py"]),
    ("diff-check", ["git", "diff", "--check"]),
)


def main() -> int:
    """Run and persist all final non-production gates."""

    results: list[dict[str, object]] = []
    for name, command in CHECKS:
        completed = subprocess.run(command, cwd=ROOT, capture_output=True, check=False)
        raw = completed.stdout + b"\n--- STDERR ---\n" + completed.stderr
        WORK.joinpath(f"final-{name}.log").write_bytes(raw)
        results.append(
            {
                "name": name,
                "command": command,
                "exit_code": completed.returncode,
                "log_sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
        print(f"{name} {completed.returncode}", flush=True)
    WORK.joinpath("final-gates.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    return 0 if all(item["exit_code"] == 0 for item in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
