"""Collect bounded DATA-02/EVID production facts in one read-only transaction."""

from __future__ import annotations

import json
import subprocess
from datetime import UTC, datetime

SQL = r"""
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '90s';
WITH active_profiles AS (
    SELECT profile_id, profile_key, environment, version, content_hash, release_ref,
           activated_at
      FROM config_center_runtime_config_profile
     WHERE environment = 'production' AND status = 'active'
),
runtime_values AS (
    SELECT value.definition_key, value.value_json, value.validation_status
      FROM config_center_runtime_config_value value
      JOIN active_profiles profile ON profile.profile_id = value.profile_id
     WHERE value.definition_key IN (
         'audit.system_event.mode',
         'audit.system_event.outbox_enabled',
         'audit.system_event.authority_selector'
     )
),
core_publications AS (
    SELECT dataset_key, publication_id, publication_hash, member_count,
           coverage_requested_count, coverage_eligible_count,
           coverage_selected_count, coverage_missing_count,
           coverage_conflict_count, as_of, published_at,
           must_not_use_for_decision, blocked_reason
      FROM data_center_canonical_publication
     WHERE publication_key = 'current'
       AND state = 'published'
       AND dataset_key IN (
           'equity.quote.snapshot',
           'equity.price.bar',
           'equity.valuation.fact',
           'equity.financial.fact'
       )
),
current_actor_heads AS (
    SELECT actor.id, actor.source_id, actor.source_version, actor.content_hash,
           actor.valid_until
      FROM account_actor_authority_source_v3_ledger actor
     WHERE actor.authority_state = 'current'
       AND actor.is_authenticated = true
       AND actor.is_active = true
       AND actor.is_staff = true
       AND actor.valid_until > CURRENT_TIMESTAMP
       AND NOT EXISTS (
           SELECT 1 FROM account_actor_authority_source_v3_ledger successor
            WHERE successor.predecessor_id = actor.id
       )
),
current_owner_heads AS (
    SELECT authority.id, authority.actor_source_id, authority.valid_until
      FROM account_owner_tenant_authority_v3_ledger authority
     WHERE authority.valid_until > CURRENT_TIMESTAMP
       AND NOT EXISTS (
           SELECT 1 FROM account_owner_tenant_authority_v3_ledger successor
            WHERE successor.predecessor_id = authority.id
       )
       AND NOT EXISTS (
           SELECT 1 FROM account_owner_tenant_authority_v3_revocation_ledger revocation
            WHERE revocation.authority_id = authority.id
       )
)
SELECT jsonb_build_object(
    'active_profiles', COALESCE((
        SELECT jsonb_agg(to_jsonb(profile) ORDER BY version)
          FROM active_profiles profile
    ), '[]'::jsonb),
    'audit_runtime_values', COALESCE((
        SELECT jsonb_object_agg(
            definition_key,
            jsonb_build_object('value', value_json, 'validation_status', validation_status)
        )
          FROM runtime_values
    ), '{}'::jsonb),
    'active_a_share_asset_count', (
        SELECT count(*)
          FROM data_center_asset_master
         WHERE asset_type = 'stock'
           AND exchange IN ('SSE', 'SZSE', 'BSE')
           AND is_active = true
    ),
    'core_current_publications', COALESCE((
        SELECT jsonb_agg(to_jsonb(publication) ORDER BY dataset_key)
          FROM core_publications publication
    ), '[]'::jsonb),
    'authority_counts', jsonb_build_object(
        'actor_source_v3', (SELECT count(*) FROM account_actor_authority_source_v3_ledger),
        'user_source_v3', (SELECT count(*) FROM account_user_authority_source_v3_ledger),
        'rbac_source_v3', (SELECT count(*) FROM account_rbac_authority_source_v3_ledger),
        'owner_tenant_v3', (SELECT count(*) FROM account_owner_tenant_authority_v3_ledger),
        'owner_tenant_v3_revocations', (SELECT count(*) FROM account_owner_tenant_authority_v3_revocation_ledger),
        'owner_assignment_receipt_v5', (SELECT count(*) FROM account_owner_assignment_provenance_receipt_v5_ledger),
        'owner_assignment_evidence_v5', (SELECT count(*) FROM account_owner_assignment_evidence_v5_ledger),
        'temporally_current_actor_leaf_heads', (SELECT count(*) FROM current_actor_heads),
        'temporally_current_owner_leaf_heads', (SELECT count(*) FROM current_owner_heads),
        'temporally_current_joined_actor_owner_pairs', (
            SELECT count(*)
              FROM current_owner_heads owner_head
              JOIN current_actor_heads actor_head ON actor_head.id = owner_head.actor_source_id
        ),
        'actor_source_max_valid_until', (
            SELECT max(valid_until) FROM account_actor_authority_source_v3_ledger
        ),
        'owner_authority_max_valid_until', (
            SELECT max(valid_until) FROM account_owner_tenant_authority_v3_ledger
        )
    )
);
ROLLBACK;
"""


def main() -> int:
    """Run the exact SQL and emit a secret-free report."""

    command = [
        "docker",
        "exec",
        "-i",
        "agomtradepro-postgres-1",
        "sh",
        "-lc",
        'exec psql -X -q -A -t -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"',
    ]
    completed = subprocess.run(
        command, input=SQL, capture_output=True, text=True, timeout=120, check=False
    )
    if completed.returncode != 0:
        print(
            json.dumps(
                {
                    "schema": "production-closure-database-readonly.v1",
                    "exit_code": completed.returncode,
                    "error": "production read-only query failed",
                    "mutations_performed": False,
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        )
        return 1
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("production read-only query returned unexpected rows")
    facts = json.loads(lines[0])
    report = {
        "schema": "production-closure-database-readonly.v1",
        "observed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "transaction": "REPEATABLE READ READ ONLY; ROLLBACK",
        "facts": facts,
        "mutations_performed": False,
        "secret_values_emitted": False,
    }
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
