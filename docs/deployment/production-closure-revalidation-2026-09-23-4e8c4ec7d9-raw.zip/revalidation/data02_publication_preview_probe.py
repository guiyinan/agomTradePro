"""Run the deployed four-Publication dry-run and emit bounded JSON evidence."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import UTC, datetime


def main() -> int:
    """Execute the no-write publication preview from the deployed Web container."""

    command = [
        "docker",
        "exec",
        "agomtradepro-web-1",
        "python",
        "manage.py",
        "rebuild_active_a_share_core_publications",
    ]
    completed = subprocess.run(
        command, capture_output=True, text=True, timeout=180, check=False
    )
    payload: object | None = None
    for line in reversed(completed.stdout.splitlines()):
        try:
            payload = json.loads(line)
        except ValueError:
            continue
        break
    report: dict[str, object] = {
        "schema": "production-closure-data02-publication-preview.v1",
        "observed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "command": command,
        "exit_code": completed.returncode,
        "execute_flag_supplied": False,
        "mutations_performed": False,
        "stdout_sha256": hashlib.sha256(completed.stdout.encode()).hexdigest(),
        "stderr_sha256": hashlib.sha256(completed.stderr.encode()).hexdigest(),
    }
    if isinstance(payload, dict) and payload.get("mode") == "dry_run":
        report["preview"] = payload
    else:
        report["stdout_last_line"] = (
            completed.stdout.splitlines()[-1][:1000] if completed.stdout.splitlines() else ""
        )
        report["stderr_last_line"] = (
            completed.stderr.splitlines()[-1][:1000] if completed.stderr.splitlines() else ""
        )
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0 if completed.returncode == 0 and "preview" in report else 1


if __name__ == "__main__":
    raise SystemExit(main())
