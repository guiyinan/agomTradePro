"""Run the deployed DATA-02 dry-run command and emit bounded JSON evidence."""

from __future__ import annotations

import json
import hashlib
import subprocess
from datetime import UTC, datetime


class Data02PreviewProbeError(ValueError):
    """Reject a failed or malformed production dry-run."""


def main() -> int:
    """Execute the no-write preview from the deployed Web container."""

    command = [
        "docker",
        "exec",
        "agomtradepro-web-1",
        "python",
        "manage.py",
        "repair_active_a_share_current_facts",
        "--source",
        "akshare",
        "--batch-size",
        "50",
    ]
    completed = subprocess.run(
        command, capture_output=True, text=True, timeout=180, check=False
    )
    if completed.returncode != 0:
        report = {
            "schema": "production-closure-data02-preview.v1",
            "observed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
            "command": command,
            "exit_code": completed.returncode,
            "stdout_sha256": hashlib.sha256(completed.stdout.encode()).hexdigest(),
            "stderr_sha256": hashlib.sha256(completed.stderr.encode()).hexdigest(),
            "stdout_last_line": completed.stdout.splitlines()[-1][:1000] if completed.stdout.splitlines() else "",
            "stderr_last_line": completed.stderr.splitlines()[-1][:1000] if completed.stderr.splitlines() else "",
            "execute_flag_supplied": False,
            "mutations_performed": False,
        }
        print(json.dumps(report, sort_keys=True, separators=(",", ":")))
        return 1
    payload: object | None = None
    for line in reversed(completed.stdout.splitlines()):
        try:
            payload = json.loads(line)
        except ValueError:
            continue
        break
    if not isinstance(payload, dict) or payload.get("mode") != "dry_run":
        raise Data02PreviewProbeError("deployed DATA-02 preview output invalid")
    if payload.get("operator") != "":
        raise Data02PreviewProbeError("deployed DATA-02 preview unexpectedly has an operator")
    report = {
        "schema": "production-closure-data02-preview.v1",
        "observed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "command": command,
        "exit_code": completed.returncode,
        "preview": payload,
        "execute_flag_supplied": False,
        "external_provider_calls_expected": False,
        "mutations_performed": False,
        "stderr_nonempty": bool(completed.stderr.strip()),
    }
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
