"""Collect current production identity and public stop lines without mutation."""

from __future__ import annotations

import hashlib
import json
import stat
import subprocess
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from typing import cast

ROOT = Path("/opt/agomtradepro")
ORIGIN = "https://demo.agomtrade.pro"


class IdentityProbeError(ValueError):
    """Reject incomplete production identity evidence."""


def _object(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise IdentityProbeError("expected object")
    return cast(dict[str, object], value)


def _inspect(name: str) -> dict[str, object]:
    completed = subprocess.run(
        ["docker", "inspect", name], capture_output=True, text=True, timeout=20, check=False
    )
    if completed.returncode != 0:
        return {"name": name, "available": False}
    payload = json.loads(completed.stdout)
    if not isinstance(payload, list) or len(payload) != 1:
        raise IdentityProbeError("ambiguous Docker identity")
    item = _object(payload[0])
    state = _object(item.get("State"))
    health = state.get("Health")
    health_status = _object(health).get("Status") if isinstance(health, dict) else None
    config = _object(item.get("Config"))
    labels = config.get("Labels")
    revision = _object(labels).get("org.opencontainers.image.revision") if isinstance(labels, dict) else None
    return {
        "name": name,
        "available": True,
        "status": state.get("Status"),
        "health": health_status,
        "started_at": state.get("StartedAt"),
        "restart_count": item.get("RestartCount"),
        "image_id": item.get("Image"),
        "image_reference": config.get("Image"),
        "oci_revision": revision,
    }


def _request(path: str) -> dict[str, object]:
    request = urllib.request.Request(ORIGIN + path)
    try:
        response = urllib.request.urlopen(request, timeout=35)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        body = response.read(2_000_000)
        return {
            "status": response.status,
            "content_type": response.headers.get("Content-Type"),
            "body_bytes": len(body),
            "body_sha256": hashlib.sha256(body).hexdigest(),
        }


def main() -> int:
    """Emit a secret-free identity report."""

    current = ROOT.joinpath("current").resolve()
    manifest = current / ".agom-release-manifest.json"
    if (
        not current.is_dir()
        or manifest.is_symlink()
        or not manifest.is_file()
        or stat.S_IMODE(manifest.stat().st_mode) != 0o444
    ):
        raise IdentityProbeError("current release manifest unavailable or unsafe")
    raw_manifest = manifest.read_bytes()
    payload = _object(json.loads(raw_manifest))
    allowed_manifest = {
        key: payload.get(key)
        for key in ("source_commit", "release_tag", "image_id", "image_tag", "created_at")
        if key in payload
    }
    report = {
        "schema": "production-closure-current-identity.v1",
        "observed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "current_release_path": str(current),
        "manifest_sha256": hashlib.sha256(raw_manifest).hexdigest(),
        "manifest": allowed_manifest,
        "containers": [
            _inspect(name)
            for name in (
                "agomtradepro-web-1",
                "agomtradepro-prometheus-1",
                "agomtradepro-worker-1",
                "agomtradepro-beat-1",
            )
        ],
        "https": {
            path: _request(path)
            for path in (
                "/api/health/",
                "/api/health/db/",
                "/api/ready/",
                "/api/decision-ready/",
                "/api/operational-readiness/release-identity/",
            )
        },
        "mutations_performed": False,
        "secret_values_emitted": False,
    }
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
