"""Verify the durable archive and staged Git blobs against executed sources."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
path = ROOT / 'docs/testing/config-center-review-fixes-2026-09-21.json'
raw = path.read_bytes()
report = json.loads(raw)
sha = lambda value: hashlib.sha256(value).hexdigest()
assert path.with_suffix('.json.sha256').read_text().split()[0] == sha(raw)
assert len(report['final_governance_gates']) == 4
assert all(item['exit_code'] == 0 for item in report['final_governance_gates'])
assert report['local_postgres_cleanup']['removed'] is True
archive = ROOT / report['archive']['path']
assert sha(archive.read_bytes()) == report['archive']['sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(report['archive']['members'])
    for name, expected in report['archive']['members'].items():
        data = z.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], name
for name, expected in report['source_bindings'].items():
    staged = subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT)
    assert sha(staged) == expected['canonical_lf_sha256'], name
for name in (path.relative_to(ROOT).as_posix(), path.relative_to(ROOT).as_posix() + '.sha256', archive.relative_to(ROOT).as_posix()):
    assert subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT) == (ROOT / name).read_bytes(), name
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, check=True)
print(json.dumps({'verified_source_files': len(report['source_bindings']), 'verified_archive_members': len(report['archive']['members']), 'evidence_sha256': sha(raw)}))
