"""Capture source-bound Config Center review validation without production access."""
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import monotonic

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / 'final'
PY = str(ROOT / 'agomtradepro/Scripts/python.exe')
PRODUCTION = [
    'apps/config_center/domain/runtime_config.py',
    'apps/config_center/application/runtime_config.py',
    'apps/config_center/application/runtime_public.py',
    'apps/config_center/infrastructure/runtime_config_repositories.py',
    'apps/config_center/management/commands/activate_runtime_profile_corrective.py',
]
TESTS = [
    'tests/unit/config_center/test_runtime_profile_integrity_review.py',
    'tests/unit/config_center/test_corrective_command_input.py',
    'tests/unit/config_center/test_aud05_hash_scope_and_activation.py',
    'tests/unit/config_center/test_runtime_definition_reconcile.py',
    'tests/component/config_center/test_aud05_atomic_activation.py',
]

def snapshot():
    return {p: {'raw_sha256': hashlib.sha256((ROOT / p).read_bytes()).hexdigest(), 'canonical_lf_sha256': hashlib.sha256((ROOT / p).read_bytes().replace(b'\r\n', b'\n')).hexdigest()} for p in PRODUCTION + TESTS}

def main():
    OUT.mkdir(exist_ok=True)
    env = dict(os.environ, DJANGO_SETTINGS_MODULE='core.settings.development_sqlite', COVERAGE_FILE=str(OUT / '.coverage'))
    checks = [
        ('black', [PY, '-m', 'black', '--check', *PRODUCTION, *TESTS]),
        ('isort', [PY, '-m', 'isort', '--check-only', *PRODUCTION, *TESTS]),
        ('ruff-delta', [PY, str(OUT.parent / 'check_ruff_delta.py')]),
        ('mypy-regression', [PY, 'scripts/check_mypy_regression.py', *PRODUCTION]),
        ('mypy-debt-ceiling', [PY, 'scripts/check_mypy_debt_ceiling.py']),
        ('config-audit-sqlite', [PY, '-X', 'utf8', '-m', 'pytest', 'tests/unit/config_center', 'tests/unit/audit/test_system_audit_runtime_config.py', 'tests/component/config_center/test_aud05_atomic_activation.py', '-q', '-o', 'addopts=', '--nomigrations', '--basetemp=' + str(OUT / 'sqlite-temp'), '--junitxml=' + str(OUT / 'sqlite.junit.xml'), '--cov=apps.config_center.domain.runtime_config', '--cov-branch', '--cov-report=json:' + str(OUT / 'coverage.json'), '--cov-report=term-missing']),
        ('migrations', [PY, 'manage.py', 'makemigrations', 'config_center', '--check', '--dry-run']),
        ('current-data', [PY, 'scripts/check_current_data_contracts.py']),
        ('architecture', [PY, 'scripts/check_architecture_delta.py', '--include-audit', '--fail-on-audit-violations']),
        ('registry', [PY, 'scripts/check_active_plan_registry.py']),
        ('governance', [PY, 'scripts/check_governance_consistency.py']),
        ('diff-check', ['git', 'diff', '--check', 'HEAD']),
    ]
    report = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'source_before': snapshot(), 'gates': []}
    for name, command in checks:
        print('START ' + name, flush=True)
        started = monotonic()
        run = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
        raw = run.stdout + b'\n--- STDERR ---\n' + run.stderr
        (OUT / (name + '.log')).write_bytes(raw)
        report['gates'].append({'name': name, 'command': command, 'exit_code': run.returncode, 'elapsed_seconds': round(monotonic() - started, 3), 'log_sha256': hashlib.sha256(raw).hexdigest()})
        (OUT / 'gates.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        print(name + ' ' + str(run.returncode), flush=True)
    report.update(source_after=snapshot(), finished_at_utc=datetime.now(timezone.utc).isoformat())
    report['source_unchanged'] = report['source_before'] == report['source_after']
    (OUT / 'gates.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return 0 if report['source_unchanged'] and all(g['exit_code'] == 0 for g in report['gates']) else 1

if __name__ == '__main__':
    sys.exit(main())
