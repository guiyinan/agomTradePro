"""Validate final governance edits after the source-bound test runs."""
import hashlib
import json
import os
import runpy
import subprocess
from pathlib import Path

WORK = Path(__file__).resolve().parent
CONFIG = runpy.run_path(str(WORK / 'run_final.py'))
OUT = WORK / 'final'
PY = CONFIG['PY']
checks = [
    ('registry', [PY, 'scripts/check_active_plan_registry.py']),
    ('governance', [PY, 'scripts/check_governance_consistency.py']),
    ('current-data', [PY, 'scripts/check_current_data_contracts.py']),
    ('diff-check', ['git', 'diff', '--check', 'HEAD']),
]
results = []
for name, command in checks:
    run = subprocess.run(command, cwd=CONFIG['ROOT'], capture_output=True, env=dict(os.environ, PYTHONUTF8='1'))
    raw = run.stdout + b'\n--- STDERR ---\n' + run.stderr
    (OUT / ('followup-' + name + '.log')).write_bytes(raw)
    results.append({'name': name, 'command': command, 'exit_code': run.returncode, 'log_sha256': hashlib.sha256(raw).hexdigest()})
    print(name, run.returncode, flush=True)
(OUT / 'governance-followup.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
raise SystemExit(0 if all(x['exit_code'] == 0 for x in results) else 1)
