"""Compare Ruff diagnostics against the unchanged source-line baseline."""
import collections
import json
import runpy
import subprocess
from pathlib import Path

config = runpy.run_path('var/validation/config-review-2026-09-21/run_final.py')
files = config['PRODUCTION'] + config['TESTS']
py = config['PY']
baseline = collections.Counter()
observed = collections.Counter()
details = {'baseline_ref': 'e779bf439', 'files': []}
for filename in files:
    old = subprocess.run(['git', 'show', details['baseline_ref'] + ':' + filename], capture_output=True)
    row = {'path': filename, 'baseline': [], 'current': []}
    for key, source, counts in [('baseline', old.stdout if old.returncode == 0 else b'', baseline), ('current', Path(filename).read_bytes(), observed)]:
        run = subprocess.run([py, '-m', 'ruff', 'check', '--output-format=json', '--stdin-filename', filename, '-'], input=source, capture_output=True)
        if run.returncode not in (0, 1):
            raise RuntimeError('Ruff failed to execute: ' + filename)
        items = json.loads(run.stdout)
        lines = source.decode('utf-8').splitlines()
        for item in items:
            label = (filename, item['code'], item['message'], lines[item['location']['row'] - 1].strip())
            counts[label] += 1
        row[key] = items
    details['files'].append(row)
regressions = observed - baseline
details['baseline_diagnostic_count'] = sum(baseline.values())
details['current_diagnostic_count'] = sum(observed.values())
details['new_diagnostics'] = [{'path': key[0], 'code': key[1], 'message': key[2], 'source_line': key[3], 'count': count} for key, count in regressions.items()]
out = config['OUT']
out.mkdir(exist_ok=True)
(out / 'ruff-delta.json').write_text(json.dumps(details, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: details[key] for key in ['baseline_ref', 'baseline_diagnostic_count', 'current_diagnostic_count', 'new_diagnostics']}, indent=2))
raise SystemExit(1 if regressions else 0)
