"""Seal tested Config Center follow-up fixes and actual validation attempts."""
import hashlib
import json
import runpy
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree

WORK = Path(__file__).resolve().parent
CONFIG = runpy.run_path(str(WORK / 'run_final.py'))
ROOT = CONFIG['ROOT']
FINAL = WORK / 'final'
DEST = ROOT / 'docs/testing'
STEM = 'config-center-review-fixes-2026-09-21'
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def read(name):
    return json.loads((FINAL / name).read_text(encoding='utf-8-sig'))
gates = read('gates.json')
pg = read('postgres.json')
assert gates['source_unchanged'] and all(g['exit_code'] == 0 for g in gates['gates'])
assert pg['source_unchanged'] and pg['exit_code'] == 0
assert gates['source_after'] == pg['source_after'] == CONFIG['snapshot']()
counts = {}
for kind in ('sqlite', 'postgres'):
    suites = ElementTree.parse(FINAL / (kind + '.junit.xml')).getroot()
    counts[kind] = {k: sum(int(s.get(k, '0')) for s in suites.iter('testsuite')) for k in ('tests', 'failures', 'errors', 'skipped')}
    assert counts[kind]['failures'] == counts[kind]['errors'] == 0
assert counts['postgres']['skipped'] == 0
coverage = read('coverage.json')['totals']
coverage['line_percent'] = 100 * coverage['covered_lines'] / coverage['num_statements']
coverage['branch_percent'] = 100 * coverage['covered_branches'] / coverage['num_branches']
assert coverage['line_percent'] >= 90 and coverage['branch_percent'] >= 90
files = {}
for path in FINAL.iterdir():
    if path.is_file() and path.suffix in ('.log', '.json', '.xml'):
        files['final/' + path.name] = path.read_bytes()
for name in ('integrity-red.log', 'component-red.log', 'validation-red.log', 'graph-red.log', 'integrity-first-green.log', 'first-regression.log', 'postgres-initialization-excluded.log', 'run_final.py', 'run_postgres.py', 'check_ruff_delta.py', 'finish_validation.py', 'verify_staged.py', 'seal.py'):
    files['attempts/' + name] = (WORK / name).read_bytes()
for path in (WORK / 'command').iterdir():
    if path.is_file() and path.suffix in ('.log', '.exit'):
        files['command/' + path.name] = path.read_bytes()
archive = DEST / (STEM + '-raw.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(files.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(z.read(n) == v for n, v in files.items())
report = {
    'schema': 'config-center-review-fixes.v1', 'status': 'verified',
    'sealed_at_utc': datetime.now(timezone.utc).isoformat(),
    'base_commit': 'e779bf439',
    'head_before_integrity_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'command_fix_commit': '336e578cb',
    'scope': 'AUD-05 repository follow-up only; no production writes or deployment; Research closure unchanged',
    'fixes': ['Verify full persisted value identity/hash before secret reads, active validation, patch preview/inheritance and direct activation.', 'Lock and reverify predecessor values before successor writes; verify candidate full hash, revision hashes and public projection consistency.', 'Reject multiple active profiles and multiple snapshots for one profile version instead of selecting one by order.', 'Parse secret-only envelopes, reject unknown envelope fields, and translate JSON/file errors into CommandError.'],
    'source_bindings': gates['source_after'], 'junit': counts, 'domain_coverage': coverage,
    'gates': gates['gates'], 'postgres': {k: v for k, v in pg.items() if k not in ('source_before', 'source_after')},
    'final_governance_gates': read('governance-followup.json') if (FINAL / 'governance-followup.json').exists() else [],
    'local_postgres_cleanup': read('postgres-cleanup.json'),
    'architecture_scope': {'integrity_working_tree': '4 production files, 72 added lines; zero boundary/audit violations', 'command_commit': 'e779bf439..336e578cb: 1 production file, 39 added lines; zero boundary/audit violations; final/command-architecture.log'},
    'red_evidence': {'full_integrity': '12 failed, 2 passed before implementation', 'active_validation': '1 failed before implementation', 'locked_predecessor': '3 failed before implementation', 'candidate_and_ambiguity': '7 failed before implementation', 'command': '4 failed before implementation'},
    'independent_review': {'reviewer': 'GPT-5.6 Luna max (/root/aud05_luna)', 'result': 'pass', 'scope': 'Final Domain/Application/Infrastructure diff; candidate graph, locked predecessor values, ambiguous reads, transaction rollback and existing PostgreSQL race logic. Root separately reviewed command parser and frozen test source.', 'non_blocking_limits': ['Low-level UoW optional predecessor snapshot remains optional; official Application service always supplies its captured snapshot.', 'No production multi-database router is configured; generalized multi-alias support was not introduced.']},
    'limitations': ['SQLite includes two explicitly PostgreSQL-only skips; PostgreSQL component run has zero skips.', 'PostgreSQL uses isolated Config Center test settings and does not prove production lifecycle, full-app migrations or restore acceptance.', 'First ordinary postgres:16 container did not finish initialization in the observed interval; its log is excluded from acceptance. Final run used the pinned previously validated image.', 'First broad unit attempt hit the system pytest temporary directory permission error; final runs use dedicated workspace basetemp paths.', 'Four historical Domain UP042 diagnostics remain; Ruff delta has zero new diagnostics.'],
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'sha256': sha(archive.read_bytes()), 'members': {n: {'bytes': len(v), 'sha256': sha(v)} for n, v in sorted(files.items())}},
}
raw = (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode()
path = DEST / (STEM + '.json')
path.write_bytes(raw)
path.with_suffix('.json.sha256').write_bytes((sha(raw) + '  ' + path.name + '\n').encode('ascii'))
print(json.dumps({'junit': counts, 'coverage': coverage, 'sha256': sha(raw), 'path': str(path)}))
