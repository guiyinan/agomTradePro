"""Run the final component suite against an isolated loopback PostgreSQL target."""
import hashlib
import json
import os
import runpy
import subprocess
from datetime import datetime, timezone
from pathlib import Path

WORK = Path(__file__).resolve().parent
config = runpy.run_path(str(WORK / 'run_final.py'))
OUT = WORK / 'final'
ROOT = config['ROOT']
PY = config['PY']
env = dict(os.environ, DJANGO_SETTINGS_MODULE='tests.settings_aud05_postgres', AGOM_AUD05_PG_CONCURRENCY_EVIDENCE='1', AGOM_AUD05_PG_HOST='127.0.0.1', AGOM_AUD05_PG_PORT='55439', AGOM_AUD05_PG_NAME='aud05_review_test', AGOM_AUD05_PG_USER='postgres', AGOM_AUD05_PG_PASSWORD='', DOCKER_API_VERSION='1.45')
before = config['snapshot']()
command = [PY, '-X', 'utf8', '-m', 'pytest', 'tests/component/config_center/test_aud05_atomic_activation.py', '--confcutdir=tests/component/config_center', '--nomigrations', '-q', '-o', 'addopts=', '--basetemp=' + str(OUT / 'postgres-temp'), '--junitxml=' + str(OUT / 'postgres.junit.xml')]
environment = subprocess.check_output(['docker', 'exec', 'agom-config-review-test-20260921', 'psql', '-U', 'postgres', '-d', 'aud05_review_test', '-Atc', 'SELECT version()'], env=env)
report = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'source_before': before, 'command': command, 'postgres_version': environment.decode().strip(), 'production_access': False, 'container_id': 'f549d90fa33c065c7a54c8515e97847e447571ef2612eb35a3bf45f14d55d42c', 'image': 'sha256:33f923b05f64ca54ac4401c01126a6b92afe839a0aa0a52bc5aeb5cc958e5f20'}
run = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
raw = run.stdout + b'\n--- STDERR ---\n' + run.stderr
(OUT / 'postgres.log').write_bytes(raw)
report.update(exit_code=run.returncode, source_after=config['snapshot'](), log_sha256=hashlib.sha256(raw).hexdigest(), finished_at_utc=datetime.now(timezone.utc).isoformat())
report['source_unchanged'] = report['source_before'] == report['source_after']
(OUT / 'postgres.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('exit_code', 'source_unchanged', 'postgres_version')}))
raise SystemExit(0 if run.returncode == 0 and report['source_unchanged'] else 1)
