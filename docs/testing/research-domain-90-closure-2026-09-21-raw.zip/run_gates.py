"""Capture the final test-only closure checks without changing production code."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
(OUT / 'gates').mkdir(exist_ok=True)
PY = str(ROOT / 'agomtradepro/Scripts/python.exe')
files = sorted(str(p.relative_to(ROOT)).replace('\\', '/') for p in (ROOT / 'tests/unit/research').glob('test_data17_*.py'))
assert len(files) >= 3
checks = [
    ('black', [PY, '-m', 'black', '--check', *files]),
    ('isort', [PY, '-m', 'isort', '--check-only', *files]),
    ('ruff', [PY, '-m', 'ruff', 'check', *files]),
    ('current-data', [PY, 'scripts/check_current_data_contracts.py']),
    ('registry', [PY, 'scripts/check_active_plan_registry.py']),
    ('governance', [PY, 'scripts/check_governance_consistency.py', '--baseline', 'governance/governance_baseline.json', '--format', 'text']),
    ('diff-check', ['git', 'diff', '--check']),
]
results = []
for name, command in checks:
    started = datetime.now(timezone.utc).isoformat()
    run = subprocess.run(command, cwd=ROOT, capture_output=True)
    raw = run.stdout + b'\n--- STDERR ---\n' + run.stderr
    path = OUT / 'gates' / (name + '.log')
    path.write_bytes(raw)
    results.append({'name': name, 'started_at_utc': started, 'command': command, 'exit_code': run.returncode, 'log_member': 'gates/' + path.name, 'log_sha256': hashlib.sha256(raw).hexdigest()})
    print(name, run.returncode, flush=True)
(OUT / 'gates.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
raise SystemExit(0 if all(r['exit_code'] == 0 for r in results) else 1)
