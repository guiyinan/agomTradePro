"""Measure a frozen complete Research unit suite against unchanged Domain sources."""
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import monotonic

ROOT = Path(__file__).resolve().parents[3]
PHASE = sys.argv[1]
assert PHASE in {'before', 'after'}
OUT = Path(__file__).resolve().parent / PHASE
OUT.mkdir(exist_ok=True)
PY = str(ROOT / 'agomtradepro/Scripts/python.exe')

def snapshot(directory):
    result = {}
    for path in sorted((ROOT / directory).rglob('*.py')):
        raw = path.read_bytes()
        result[path.relative_to(ROOT).as_posix()] = {'bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(), 'canonical_lf_sha256': hashlib.sha256(raw.replace(b'\r\n', b'\n')).hexdigest()}
    return result

env = dict(os.environ)
env['DJANGO_SETTINGS_MODULE'] = 'core.settings.development_sqlite'
env['COVERAGE_FILE'] = str(OUT / '.coverage')
command = [PY, '-X', 'utf8', '-m', 'pytest', 'tests/unit/research/', '-q', '-o', 'addopts=', '--nomigrations', '--basetemp=' + str(OUT / 'pytest-temp'), '--cov=apps.research.domain', '--cov-branch', '--cov-report=json:' + str(OUT / 'coverage.json'), '--cov-report=term-missing', '--junitxml=' + str(OUT / 'junit.xml')]
report = {'phase': PHASE, 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'python_version': platform.python_version(), 'command': command, 'domain_before': snapshot('apps/research/domain'), 'tests_before': snapshot('tests/unit/research'), 'production_access': False, 'postgresql_validation': False}
(OUT / 'measurement.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print('START complete Research ' + PHASE, flush=True)
started = monotonic()
run = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
log = OUT / 'pytest.log'
log.write_bytes(run.stdout + b'\n--- STDERR ---\n' + run.stderr)
report.update({'exit_code': run.returncode, 'elapsed_seconds': round(monotonic() - started, 3), 'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'domain_after': snapshot('apps/research/domain'), 'tests_after': snapshot('tests/unit/research'), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
report['domain_unchanged'] = report['domain_before'] == report['domain_after']
report['tests_unchanged'] = report['tests_before'] == report['tests_after']
if (OUT / 'coverage.json').exists():
    totals = json.loads((OUT / 'coverage.json').read_text(encoding='utf-8'))['totals']
    report['coverage'] = {**totals, 'line_percent': 100 * totals['covered_lines'] / totals['num_statements'], 'branch_percent': 100 * totals['covered_branches'] / totals['num_branches']}
(OUT / 'measurement.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('phase', 'exit_code', 'elapsed_seconds', 'domain_unchanged', 'tests_unchanged', 'coverage') if k in report}), flush=True)
raise SystemExit(0 if run.returncode == 0 and report['domain_unchanged'] and report['tests_unchanged'] else 1)
