"""Seal actual full-suite evidence only after successful source-stable validation."""
import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/testing'
STEM = 'research-domain-90-closure-2026-09-21'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load(name):
    return json.loads((WORK / name).read_text(encoding='utf-8'))

before = load('before/measurement.json')
after = load('after/measurement.json')
before_meta = load('before/coverage.json')['meta']
after_meta = load('after/coverage.json')['meta']
assert before_meta['version'] == after_meta['version']
assert before_meta['format'] == after_meta['format']
assert before_meta['branch_coverage'] and after_meta['branch_coverage']
assert before['exit_code'] == after['exit_code'] == 0
assert all(m['domain_unchanged'] and m['tests_unchanged'] for m in (before, after))
assert before['domain_before'] == after['domain_before']
assert all(after['tests_before'][p] == v for p, v in before['tests_before'].items())
assert before['coverage']['num_branches'] == after['coverage']['num_branches'] == 5032
assert before['coverage']['num_statements'] == after['coverage']['num_statements'] == 13546
assert before['coverage']['excluded_lines'] == after['coverage']['excluded_lines'] == 2
assert after['coverage']['branch_percent'] >= 90 and after['coverage']['line_percent'] >= 90
for path, binding in {**after['domain_before'], **after['tests_before']}.items():
    assert sha((ROOT / path).read_bytes()) == binding['raw_sha256'], path
assert subprocess.check_output(['git', 'diff', 'dea925d83', '--', 'apps/research/domain'], cwd=ROOT) == b''
gates = load('gates.json')
assert all(g['exit_code'] == 0 for g in gates)
review = load('independent-review.json')
assert review['outcome'] == 'pass'
for item in review['reviews']:
    assert sha((ROOT / item['file']).read_bytes()) == item['sha256']
members = {}
for phase in ('before', 'after'):
    for name in ('measurement.json', 'coverage.json', 'junit.xml', 'pytest.log'):
        members[phase + '/' + name] = (WORK / phase / name).read_bytes()
for name in ('measurement.json', 'pytest.log'):
    members['excluded/after-interrupted-import-format/' + name] = (WORK / 'after-interrupted-import-format' / name).read_bytes()
for name in ('measure_whole.py', 'seal_evidence.py', 'run_gates.py', 'gates.json', 'independent-review.json'):
    members[name] = (WORK / name).read_bytes()
for name in ('peer-focused-final.log', 'r4/stdout-focused-final.log', 'r4/coverage-focused-final.json', 'r4/junit-focused-final.xml', 'data17-luna-final.log', 'agent-aud05-final/focused.stdout-stderr.log'):
    members['supporting/' + name] = (WORK / name).read_bytes()
for path in after['tests_before']:
    if path not in before['tests_before']:
        members['sources/' + path] = (ROOT / path).read_bytes()
for path in sorted((WORK / 'gates').glob('*.log')):
    members['gates/' + path.name] = path.read_bytes()
archive = DEST / (STEM + '-raw.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(members.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(z.read(name) == raw for name, raw in members.items())
tests = {}
for phase in ('before', 'after'):
    suites = ElementTree.parse(WORK / phase / 'junit.xml').getroot()
    tests[phase] = {key: sum(int(s.get(key, '0')) for s in suites.iter('testsuite')) for key in ('tests', 'failures', 'errors', 'skipped')}
report = {
    'schema': 'research-domain-90-repository-closure.v1',
    'sealed_at_utc': datetime.now(timezone.utc).isoformat(),
    'unit_id': 'DATA-17', 'outcome': 'completed',
    'git_head_before_closure_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'scope': 'Full tests/unit/research against unchanged apps/research/domain; local SQLite only',
    'measurement_runtime': {'python_version': after['python_version'], 'coverage_version': after_meta['version'], 'coverage_format': after_meta['format']},
    'before': {'coverage': before['coverage'], 'junit': tests['before'], 'elapsed_seconds': before['elapsed_seconds']},
    'after': {'coverage': after['coverage'], 'junit': tests['after'], 'elapsed_seconds': after['elapsed_seconds']},
    'new_covered_branches': after['coverage']['covered_branches'] - before['coverage']['covered_branches'],
    'domain_sources': after['domain_before'],
    'existing_test_files_unchanged': len(before['tests_before']),
    'new_test_sources': {p: v for p, v in after['tests_before'].items() if p not in before['tests_before']},
    'governance_and_document_bindings': {p: {'raw_sha256': sha((ROOT / p).read_bytes()), 'canonical_lf_sha256': sha((ROOT / p).read_bytes().replace(b'\r\n', b'\n'))} for p in ('governance/active_plan_registry.json', 'docs/plans/README.md', 'docs/plans/data-evidence-audit-runtime-sprint-route-2026-09-14.md', 'docs/reviews/production-closure-2026-09-20.md', '.gitattributes')},
    'gates': gates, 'independent_review': review,
    'excluded_attempts': [{'path_in_archive': 'excluded/after-interrupted-import-format', 'reason': 'Stopped the verified local pytest process after final import-format validation exposed an isort/Ruff conflict. Final frozen-source full after run was restarted; the interrupted run supplies no accepted coverage or passing-test claim.'}],
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'members': {n: {'bytes': len(r), 'sha256': sha(r)} for n, r in sorted(members.items())}},
    'limitations': ['No production Python changes; incremental mypy/debt gates are not required for these test-only changes.', 'No PostgreSQL, VPS, vendor, strategy registration, PIT/OOS or production acceptance is inferred.', 'Existing two excluded lines are unchanged; no new exclusions or denominator reduction.', 'This is the complete local Research unit scope, not all repository tests or a Nightly CI result.'],
}
path = DEST / (STEM + '.json')
raw = (json.dumps(report, indent=2, ensure_ascii=False) + '\n').encode('utf-8')
path.write_bytes(raw)
path.with_suffix('.json.sha256').write_text(sha(raw) + '  ' + path.name + '\n', encoding='ascii')
print(json.dumps({'path': str(path), 'sha256': sha(raw), 'branches': after['coverage']['branch_percent'], 'junit': tests, 'archive_bytes': archive.stat().st_size}))
